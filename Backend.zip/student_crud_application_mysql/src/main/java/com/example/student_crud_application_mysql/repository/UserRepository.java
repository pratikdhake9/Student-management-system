//UserRepository.java
/*
 * This is the repository interface for the User entity.
 * It extends the JpaRepository interface, which provides basic CRUD operations
 * and other useful methods for working with the User entity.
 */

package com.example.student_crud_application_mysql.repository;
import com.example.student_crud_application_mysql.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User,Long> {
}
