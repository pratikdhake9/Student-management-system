//User created by 2023-06-16T11:28:22.606+05:30
/*
 * This is a Java class representing a User entity in a database.
 * It has fields for id, username, name, and email.
 * The @Entity annotation is used to mark this class as a JPA entity,
 * and the @GeneratedValue annotation is used to specify the generation strategy for the id field.
 */

package com.example.student_crud_application_mysql.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String username;
    private String name;
    private String email;

    public User() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
