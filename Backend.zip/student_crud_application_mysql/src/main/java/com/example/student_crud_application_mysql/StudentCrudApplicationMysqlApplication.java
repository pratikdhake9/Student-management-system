package com.example.student_crud_application_mysql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentCrudApplicationMysqlApplication {

    public static void main(String[] args) {
        SpringApplication.run(StudentCrudApplicationMysqlApplication.class, args);
    }

}

